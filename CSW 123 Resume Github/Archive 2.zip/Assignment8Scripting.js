var document;
function addNumbers(n1, n2) {
    
    document.getElementById("result").innerHTML=n1+n2;
    document.getElementById("p1").innerHTML=n1+n2;
}

function subtractNumbers(n1, n2) {
    
    
    document.getElementById("result").innerHTML=n1-n2;
    document.getElementById("p1").innerHTML=n1-n2;
    
}

function multiplyNumbers(n1, n2) {
    
    
    document.getElementById("result").innerHTML=n1*n2;
    document.getElementById("p1").innerHTML=n1*n2;
    
}

function divideNumbers(n1, n2) {
    
    
    document.getElementById("result").innerHTML=n1/n2;
    document.getElementById("p1").innerHTML=n1/n2;
    
    
}
